# SamDu Telegram Bot

Telegram chat bot powered by the Google Gemini API.

## Setup

1. Install Python 3.13 or later.
2. Create and activate a virtual environment:

   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

3. Install dependencies:

   ```powershell
   pip install -r requirements.txt
   ```

4. Copy `main.env.example` to `main.env` and set your Telegram bot token and
   Gemini API key in `main.env`.
5. Start the bot:

   ```powershell
   python bot.py
   ```

The `main.env` file contains secrets and is excluded from Git.
